#include <stdio.h>
#define pi 3.14

void calc_esfera(float R, float *area, float *volume) {
    *area = 4 * pi * R * R;                
    *volume = (4.0f / 3.0f) * pi * R * R * R;  
}

int main() {
    float raio, area, volume;

    printf("Digite o raio da esfera: ");
    scanf("%f", &raio);

    calc_esfera(raio, &area, &volume);

    printf("�rea da superficie: %f\n", area);
    printf("Volume: %.4f\n", volume);

    return 0;
}

