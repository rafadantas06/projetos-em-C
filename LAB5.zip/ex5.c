#include <stdio.h>

void min_max(int V[], int N, int *min, int *max) {
    *min = V[0];
    *max = V[0];
    
    int i;
    for (i = 1; i < N; i++) {
        if (V[i] < *min) {
            *min = V[i];
        }
        if (V[i] > *max) {
            *max = V[i];
        }
    }
}

int main() {
    int V[] = {10, 5, 8, 20, 3, 15};
    int N = sizeof(V) / sizeof(V[0]);
    int minimo, maximo;

    min_max(V, N, &minimo, &maximo);

    printf("Valor minimo do array: %d\n", minimo);
    printf("Valor maximo do array: %d\n", maximo);

    return 0;
}

