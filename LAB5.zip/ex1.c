#include <stdio.h>

int soma_dobro(int *a, int *b) {
    *a = *a * 2;  
    *b = *b * 2;  
    return *a + *b;  
}

int main() {
    int a, b, resultado;

    printf("Digite o valor de A: ");
    scanf("%d", &a);

    printf("Digite o valor de B: ");
    scanf("%d", &b);

    resultado = soma_dobro(&a, &b);
    
    printf("Dobro de A: %d\n", a);
    printf("Dobro de B: %d\n", b);
    printf("Soma do dobro de A e B: %d\n", resultado);

    return 0;
}


