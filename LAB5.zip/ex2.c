#include <stdio.h>

void frac(float num, int* inteiro, float* frac) {
    *inteiro = (int)num;          
    *frac = num - *inteiro;      
}

int main() {
    float num, parte_frac;
    int parte_int;

    printf("Digite um numero real: ");
    scanf("%f", &num);

    frac(num, &parte_int, &parte_frac);

    printf("Parte inteira: %d\n", parte_int);
    printf("Parte fracionaria: %.6f\n", parte_frac);

    return 0;
}

