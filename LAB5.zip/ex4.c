#include <stdio.h>

void maior_e_ocorrencias(int arr[], int N, int *maior, int *ocorrencias) {
    *maior = arr[0];
    *ocorrencias = 1;

    int i;
    for (i = 1; i < N; i++) {
        if (arr[i] > *maior) {
            *maior = arr[i];
            *ocorrencias = 1; 
        } else if (arr[i] == *maior) {
            (*ocorrencias)++;
        }
    }
}

int main() {
    int array[] = {5, 2, 15, 3, 7, 15, 8, 6, 15};
    int N = sizeof(array) / sizeof(array[0]);
    int maior_valor, vezes;

    maior_e_ocorrencias(array, N, &maior_valor, &vezes);

    printf("Maior elemento: %d\n", maior_valor);
    printf("Numero de ocorrencias: %d\n", vezes);

    return 0;
}


