#include <stdio.h>
#include <ctype.h> 

void cifraDeCesar(char *str) {
    int i = 0;
    while (str[i] != '\0') {
        char c = str[i];

        if (isalpha(c)) {
            c = toupper(c);

            c = ((c - 'A' + 3) % 26) + 'A';
        }

        str[i] = c;
        i++;
    }
}

int main() {
    char texto[200];

    printf("Digite uma frase: ");
    fgets(texto, 200, stdin); 

    cifraDeCesar(texto);

    printf("Frase criptografada: %s\n", texto);

    return 0;
}

