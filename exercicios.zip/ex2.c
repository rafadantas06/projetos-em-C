#include <stdio.h>
#define TRUE 1
#define FALSE 0

int comparaStrings(char *str1, char *str2) {
    while (*str1 != '\0' && *str2 != '\0') {
        if (*str1 != *str2) {
            return FALSE; 
        }
        str1++; 
        str2++;
    }
    
    if (*str1 == '\0' && *str2 == '\0')
        return TRUE;
    else
        return FALSE;
}

int main() {
    char palavra1[50], palavra2[50];

    printf("Digite a primeira palavra: ");
    scanf("%s", palavra1);

    printf("Digite a segunda palavra: ");
    scanf("%s", palavra2);

    if (comparaStrings(palavra1, palavra2) == TRUE) {
        printf("As strings sao IGUAIS.\n");
    } else {
        printf("As strings sao DIFERENTES.\n");
    }

    return 0;
}

