#include <stdio.h>
#include <string.h>
#define MAX_ALUNOS 5
#define MAX_NOME 50

int main() {
    char alunos[MAX_ALUNOS][MAX_NOME];
    char busca[MAX_NOME];
    int count = 0;
    char resposta;

    while (count < MAX_ALUNOS) {
        printf("Digite o nome do aluno %d: ", count + 1);
        fgets(alunos[count], MAX_NOME, stdin);

        alunos[count][strcspn(alunos[count], "\n")] = '\0';

        count++;

        if (count < MAX_ALUNOS) {
            printf("Deseja inserir mais um nome? (s/n): ");
            scanf(" %c", &resposta);
            getchar(); 
            if (resposta == 'n' || resposta == 'N') {
                break;
            }
        }
    }

    printf("Digite um nome ou parte do nome para procurar: ");
    fgets(busca, MAX_NOME, stdin);
    busca[strcspn(busca, "\n")] = '\0'; 

    int encontrado = 0;
    for (int i = 0; i < count; i++) {
        if (strstr(alunos[i], busca) != NULL) {
            printf("Encontrado: %s (indice %d)\n", alunos[i], i);
            encontrado = 1;
        }
    }

    if (!encontrado) {
        printf("Nome nao encontrado na lista.\n");
    }

    return 0;
}

