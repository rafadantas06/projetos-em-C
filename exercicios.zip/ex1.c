#include <stdio.h>

int main() {
    char nome[20];
    char sexo;
    int idade;
    
    printf("Digite seu nome: ");
    scanf("%s", nome);
    
    printf("Digite seu sexo (M/F): ");
    scanf(" %c", &sexo); 
    
    printf("Digite sua idade: ");
    scanf("%d", &idade);
    
    if (sexo == 'F' || sexo == 'f') {
        if (idade < 25) {
            printf("%s ACEITA\n", nome);
        } else {
            printf("%s NAO ACEITA\n", nome);
        }
    } else {
        printf("%s NAO ACEITA\n", nome);
    }

    return 0;
}


