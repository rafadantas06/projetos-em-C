#include <stdio.h>

void imprimir_intersecao(int A[], int tamanhoA, int B[], int tamanhoB) {
    int encontrou = 0;

    printf("A n B = {");
    
    int i;
    for (i = 0; i < tamanhoA; i++) {
    	int j;
        for (j = 0; j < tamanhoB; j++) {
            if (A[i] == B[j]) {
                if (encontrou) {
                    printf(", ");
                }
                printf("%d", A[i]);
                encontrou = 1;
                break;
            }
        }
    }

    printf("}\n");
}

int main() {
    int tamanhoA, tamanhoB;

    printf("Digite o tamanho do vetor A: ");
    scanf("%d", &tamanhoA);
    int A[tamanhoA];

    printf("Digite os %d valores do vetor A (sem repetidos):\n", tamanhoA);
    int i;
    for (i = 0; i < tamanhoA; i++) {
        scanf("%d", &A[i]);
    }

    printf("Digite o tamanho do vetor B: ");
    scanf("%d", &tamanhoB);
    int B[tamanhoB];

    printf("Digite os %d valores do vetor B (sem repetidos):\n", tamanhoB);
    for ( i = 0; i < tamanhoB; i++) {
        scanf("%d", &B[i]);
    }

    imprimir_intersecao(A, tamanhoA, B, tamanhoB);

    return 0;
}



