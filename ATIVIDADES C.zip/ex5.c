#include <stdio.h>

void imprimir_uniao(int A[], int tamanhoA, int B[], int tamanhoB) {
    int encontrou;

    printf("A U B = {");
    
    int i;
    for (i = 0; i < tamanhoA; i++) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", A[i]);
    }

    int primeiroElementoB = 1;
    for (i = 0; i < tamanhoB; i++) {
        encontrou = 0;
        int j;
        for (j = 0; j < tamanhoA; j++) {
            if (B[i] == A[j]) {
                encontrou = 1;
                break;
            }
        }
        if (!encontrou) {
            if (tamanhoA > 0 || !primeiroElementoB) {
                printf(", ");
            }
            printf("%d", B[i]);
            primeiroElementoB = 0;
        }
    }

    printf("}\n");
}

int main() {
    int tamanhoA, tamanhoB;

    printf("Digite o tamanho do vetor A: ");
    scanf("%d", &tamanhoA);
    int A[tamanhoA];

    printf("Digite os %d valores do vetor A (sem repetidos):\n", tamanhoA);
    int i;
	for (i = 0; i < tamanhoA; i++) {
        scanf("%d", &A[i]);
    }

    printf("Digite o tamanho do vetor B: ");
    scanf("%d", &tamanhoB);
    int B[tamanhoB];

    printf("Digite os %d valores do vetor B (sem repetidos):\n", tamanhoB);
    for (i = 0; i < tamanhoB; i++) {
        scanf("%d", &B[i]);
    }

    imprimir_uniao(A, tamanhoA, B, tamanhoB);

    return 0;
}


