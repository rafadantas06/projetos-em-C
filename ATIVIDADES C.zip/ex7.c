#include <stdio.h>

int encontrar_posicao(int vetor[], int tamanho, int x) {
	int i;
    for (i = 0; i < tamanho; i++) {
        if (vetor[i] == x) {
            return i;  
        }
    }
    return -1;  
}

int main() {
    int vetor[5];
    int x;

    printf("Digite 5 valores inteiros (sem repetidos):\n");
    int i;
    for (i = 0; i < 5; i++) {
        scanf("%d", &vetor[i]);
    }

    printf("Digite o valor x a ser buscado:\n");
    scanf("%d", &x);

    int posicao = encontrar_posicao(vetor, 5, x);

    if (posicao != -1) {
        printf("O valor %d esta na posicao %d do vetor.\n", x, posicao);
    } else {
        printf("O valor %d n�o foi encontrado no vetor.\n", x);
    }

    return 0;
}

