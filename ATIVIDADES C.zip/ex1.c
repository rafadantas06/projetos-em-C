#include <stdio.h>
#include <stdbool.h>

bool ordem_crescente(int vetor[], int tamanho) {
	int i;
    for (i = 0; i < tamanho - 1; i++) {
        if (vetor[i] > vetor[i + 1]) {
            return false;
        }
    }
    return true; 
}

int main() {
    int tamanho;

    printf("Digite o tamanho do vetor: ");
    scanf("%d", &tamanho);

    int vetor[tamanho];

    printf("Digite os %d elementos do vetor:\n", tamanho);
    int i;
    for (i = 0; i < tamanho; i++) {
        scanf("%d", &vetor[i]);
    }

    if (ordem_crescente(vetor, tamanho)) {
        printf("O vetor esta em ordem crescente.\n");
    } else {
        printf("O vetor nao esta em ordem crescente.\n");
    }

    return 0;
}

