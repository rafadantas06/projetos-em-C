#include <stdio.h>

int contar_valores_diferentes(int vetor[], int tamanho) {
    int count = 0;

    int i;
    for (i = 0; i < tamanho; i++) {
        int repetido = 0;
        int j;
        for (j = 0; j < i; j++) {
            if (vetor[i] == vetor[j]) {
                repetido = 1;
                break;
            }
        }
        if (!repetido) {
            count++;
        }
    }
    return count;
}

int main() {
    int vetor[10];

    printf("Digite 10 valores inteiros:\n");
    int i;
    for (i = 0; i < 10; i++) {
        scanf("%d", &vetor[i]);
    }

    int diferentes = contar_valores_diferentes(vetor, 10);
    printf("Quantidade de valores diferentes: %d\n", diferentes);

    return 0;
}

