#include <stdio.h>
#include <stdbool.h>

bool existe_tri(float a, float b, float c) {
    if (a < b + c && b < a + c && c < a + b) {
        return true;  
    } else {
        return false; 
    }
}

bool resultado(bool existe) {
    if (existe) {
        printf("Os lados formam um triangulo \n");
    } else {
        printf("Os lados nao formam um triangulo\n");
    }
    return existe;
}

int main() {
    float a, b, c;
    bool existe;

    printf("Digite o lado a: ");
    scanf("%f", &a);

    printf("Digite o lado b: ");
    scanf("%f", &b);

    printf("Digite o lado c: ");
    scanf("%f", &c);

    existe = existe_tri(a, b, c);
    resultado(existe);

    return 0;
}

