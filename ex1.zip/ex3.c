#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int sortear_num() {
    return rand() % 100 + 1; 
}

int obter_ppt() {
    int palpite;
    do {
        printf("Digite seu palpite (1 a 100): ");
        scanf("%d", &palpite);

        if (palpite < 1 || palpite > 100) {
            printf("Valor invalido! Tente novamente.\n");
        }

    } while (palpite < 1 || palpite > 100);

    return palpite;
}

int verificar_ppt(int sorteado, int palpite) {
    if (palpite == sorteado) {
        return 0;
    } else if (palpite < sorteado) {
        return -1;
    } else {
        return 1;
    }
}

int main() {
    int sorteado, palpite, resultado;

    srand(time(NULL));

    sorteado = sortear_num();

    palpite = obter_ppt();

    resultado = verificar_ppt(sorteado, palpite);

    if (resultado == 0) {
        printf("Parabens! Voce acertou!\n");
    } else if (resultado == -1) {
        printf("Voce chutou muito baixo! O valor correto eh %d.\n", sorteado);
    } else {
        printf("Voce chutou muito alto! O valor correto eh %d.\n", sorteado);
    }

    return 0;
}


