#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Fun��o para sortear n�mero de 1 a 100
int sortear_num() {
    return rand() % 100 + 1;
}

// Fun��o para obter palpite v�lido do usu�rio
int obter_ppt() {
    int palpite;
    while (1) {
        printf("Digite seu palpite (1 a 100): ");
        scanf("%d", &palpite);

        if (palpite >= 1 && palpite <= 100) {
            return palpite;
        } else {
            printf("Valor invalido! Tente novamente.\n");
        }
    }
}

// Fun��o para verificar palpite
// retorna 0 = acertou, -1 = baixo, 1 = alto
int verificar_ppt(int sorteado, int palpite) {
    if (palpite == sorteado) {
        return 0;
    } else if (palpite < sorteado) {
        return -1;
    } else {
        return 1;
    }
}

// Fun��o para mostrar resultado final
int mostra_resultado(int resultado, int tentativas, int sorteado) {
    if (resultado == 0) {
        printf("\nParabens!!! Voce acertou!\n");
        printf("Numero de tentativas: %d\n", tentativas);
    } else {
        printf("\nVoce excedeu o numero maximo de tentativas.\n");
        printf("O numero sorteado era: %d\n", sorteado);
    }
    return 0; // s� para manter retorno int
}

int main() {
    int sorteado, palpite, resultado = -1, tentativas = 0;
    const int maxTentativas = 5;

    srand(time(NULL));
    sorteado = sortear_num();

    while (resultado != 0 && tentativas < maxTentativas) {
        palpite = obter_ppt();
        tentativas++;

        resultado = verificar_ppt(sorteado, palpite);

        if (resultado == -1) {
            printf("Voce chutou muito baixo!\n");
        } else if (resultado == 1) {
            printf("Voce chutou muito alto!\n");
        }
    }

    mostra_resultado(resultado, tentativas, sorteado);

    return 0;
}
