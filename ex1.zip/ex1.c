#include <stdio.h>

float dados(float media, int freq) {
    if (freq < 75) {
        printf("Aluno reprovado \n");
    } else if (media >= 7.5) {
        printf("Aluno aprovado \n");
    } else {
        printf("Aluno de exame \n");
    }
}

int main() {
    float media;
	int freq;

    printf("Digite a sua media (0.0 a 10.0): ");
    scanf("%f", &media);

    printf("Digite a sua frequencia em porcentagem (0 a 100): ");
    scanf("%d", &freq);

    dados(media, freq);

    return 0;

}




