#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

int sortear_num() {
    return rand() % 100 + 1; 
}

int obter_ppt() {
    int palpite;
    bool valido = false;

    while (!valido) {
        printf("Digite seu palpite (1 a 100): ");
        scanf("%d", &palpite);

        if (palpite >= 1 && palpite <= 100) {
            valido = true;
        } else {
            printf("Valor invalido! Tente novamente.\n");
        }
    }

    return palpite;
}

int verificar_ppt(int sorteado, int palpite) {
    if (palpite == sorteado) {
        return 0;
    } else if (palpite < sorteado) {
        return -1;
    } else {
        return 1;
    }
}

int main() {
    int sorteado, palpite, resultado, tentativas = 0;
    bool acertou = false;

    srand(time(NULL));

    sorteado = sortear_num();

    while (!acertou) {
        palpite = obter_ppt();
        tentativas++;

        resultado = verificar_ppt(sorteado, palpite);

        if (resultado == -1) {
            printf("Voce chutou muito baixo!\n");
        } else if (resultado == 1) {
            printf("Voce chutou muito alto!\n");
        } else {
            acertou = true;
        }
    }

    printf("Parabens! Voce acertou!\n");
    printf("Numero de tentativas: %d\n", tentativas);

    return 0;
}

