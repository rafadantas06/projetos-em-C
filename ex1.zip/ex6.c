#include <stdio.h>

int ler_idade() {
    int idade;
    printf("Digite a idade do nadador: ");
    scanf("%d", &idade);
    return idade;
}

int classificar_nadador(int idade) {
    if (idade >= 5 && idade <= 7) {
        return 1;
    } else if (idade >= 8 && idade <= 10) {
        return 2;
    } else if (idade >= 11 && idade <= 13) {
        return 3;
    } else if (idade >= 14 && idade <= 17) {
        return 4; 
    } else if (idade >= 18) {
        return 5; 
    } else {
        return 0; 
    }
}

int mostrar_resultado(int idade, int categoria) {
    printf("Nadador de %d anos pertence a categoria: ", idade);
    if (categoria == 1) {
        printf("Infantil A\n");
    } else if (categoria == 2) {
        printf("Infantil B\n");
    } else if (categoria == 3) {
        printf("Juvenil A\n");
    } else if (categoria == 4) {
        printf("Juvenil B\n");
    } else if (categoria == 5) {
        printf("Adulto\n");
    } else {
        printf("Idade invalida\n");
    }
    return categoria;
}

int main() {
    int idade, categoria;

    idade = ler_idade();
    categoria = classificar_nadador(idade);
    mostrar_resultado(idade, categoria);

    return 0;
}
